/*饼图*/
    var optionColor = ["#ff9873","#6495ed","#87cefa","#da70d6","#32cd32","#1d92e3","#fbc700"];
   var datas = ['质量类','灌水类','咨询类','需求类'];
    var data = [{value:735, name:'质量类'},
                {value:310, name:'灌水类'},
                {value:234, name:'咨询类'},
                {value:135, name:'需求类'},
            ];

    $(function(){
        //生成饼状图
        var myCharts1 = echarts.init(document.getElementById('pic1'));

        var option1 = {
                        tooltip : {
                            trigger: 'item',
                            formatter: "{a} <br/>{b} : {c} ({d}%)"
                        },
                        legend: {
                            orient : 'vertical',
                            x : 'right',
                            data:datas
                        },
                        toolbox: {
                            show : false,
                            feature : {
                                mark : {show: true},
                                dataView : {show: true, readOnly: false},
                                magicType : {
                                    show: true, 
                                    type: ['pie', 'funnel'],
                                    option: {
                                        funnel: {
                                            x: '25%',
                                            width: '50%',
                                            funnelAlign: 'center',
                                            max: 1548
                                        }
                                    }
                                },
                                restore : {show: true},
                                saveAsImage : {show: true}
                            }
                        },
                        calculable : true,
                        series : [
                            {
                                name:'VOC问题类型',
                                type:'pie',
                                radius : ['50%', '70%'],
                                itemStyle : {
                                    normal : {
                                        label : {
                                            show : true
                                        },
                                        labelLine : {
                                            show : true
                                        }
                                    },
                                    emphasis : {
                                        label : {
                                            show : true,
                                            position : 'center',
                                            textStyle : {
                                                fontSize : '30',
                                                fontWeight : 'bold'
                                            }
                                        }
                                    }
                                },
                                data:data
                            }
                        ]
                    };
        myCharts1.setOption(option1);

});

$(document).ready(function() {
    $('#example').DataTable();
/*    ( {
        "data":data,
        "columns": [
            { "data": "name" },
            { "data": "position" },
            { "data": "office" },
            { "data": "extn" },
            { "data": "start_date" },
            { "data": "salary" }
        ]
    } );*/
} );