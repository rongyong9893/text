/*饼图*/
    var optionColor = ["#ff9873","#6495ed","#87cefa","#da70d6","#32cd32","#1d92e3","#fbc700"];
   var datas = ['质量类','灌水类','咨询类','需求类'];
    var data = [{value:735, name:'质量类'},
                {value:310, name:'灌水类'},
                {value:234, name:'咨询类'},
                {value:135, name:'需求类'},
            ];

    $(function(){
        //生成饼状图
        var myCharts1 = echarts.init(document.getElementById('pic1'));

        var option1 = {
                        tooltip : {
                            trigger: 'item',
                            formatter: "{a} <br/>{b} : {c} ({d}%)"
                        },
                        legend: {
                            orient : 'vertical',
                            x : 'right',
                            data:datas
                        },
                        toolbox: {
                            show : false,
                            feature : {
                                mark : {show: true},
                                dataView : {show: true, readOnly: false},
                                magicType : {
                                    show: true, 
                                    type: ['pie', 'funnel'],
                                    option: {
                                        funnel: {
                                            x: '25%',
                                            width: '50%',
                                            funnelAlign: 'center',
                                            max: 1548
                                        }
                                    }
                                },
                                restore : {show: true},
                                saveAsImage : {show: true}
                            }
                        },
                        calculable : true,
                        series : [
                            {
                                name:'VOC问题类型',
                                type:'pie',
                                radius : ['50%', '70%'],
                                itemStyle : {
                                    normal : {
                                        label : {
                                            show : true
                                        },
                                        labelLine : {
                                            show : true
                                        }
                                    },
                                    emphasis : {
                                        label : {
                                            show : true,
                                            position : 'center',
                                            textStyle : {
                                                fontSize : '30',
                                                fontWeight : 'bold'
                                            }
                                        }
                                    }
                                },
                                data:data
                            }
                        ]
                    };
        myCharts1.setOption(option1);

});

// $(document).ready(function() {
//     $('#example').DataTable({
        
//     });
//     ( {
//         "data":data,
//         "columns": [
//             { "data": "name" },
//             { "data": "position" },
//             { "data": "office" },
//             { "data": "extn" },
//             { "data": "start_date" },
//             { "data": "salary" }
//         ]
//     } );
// } );

$(function(){

var myCharts2 = echarts.init(document.getElementById('pic2'));
  var  option = {
    title: {
        text: '折线图堆叠'
    },
    tooltip: {
        trigger: 'axis'
    },
    legend: {
        data:['邮件营销','联盟广告','视频广告','直接访问','搜索引擎']
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    toolbox: {
        feature: {
            saveAsImage: {}
        }
    },
    xAxis: {
        type: 'category',
        boundaryGap: false,
        data: ['周一','周二','周三','周四','周五','周六','周日']
    },
    yAxis: {
        type: 'value'
    },
    series: [
        {
            name:'邮件营销',
            type:'line',
            stack: '总量',
            data:[120, 132, 101, 134, 90, 230, 210]
        },
        {
            name:'联盟广告',
            type:'line',
            stack: '总量',
            data:[220, 182, 191, 234, 290, 330, 310]
        },
        {
            name:'视频广告',
            type:'line',
            stack: '总量',
            data:[150, 232, 201, 154, 190, 330, 410]
        },
        {
            name:'直接访问',
            type:'line',
            stack: '总量',
            data:[320, 332, 301, 334, 390, 330, 320]
        },
        {
            name:'搜索引擎',
            type:'line',
            stack: '总量',
            data:[820, 932, 901, 934, 1290, 1330, 1320]
        }
    ]
};
        myCharts2.setOption(option);   
})