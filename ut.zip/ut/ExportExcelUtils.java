package com.rong.demo.utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class ExportExcelUtils
{
    // 这是记录log日志的，没有配的话可忽略
   // public static final Logger log = LogManager.getLogger(ExportExcelUtils.class);

    /**
     * 导出列表数据
     * @param title 表头集合
     * @param position  表头字段位置集合
     * @param styleMap 需要导出的数据
     * @param sheetName 导出数据后在excel表格中左下角显示的工作簿名称（注意：不是导出后的文件名）
     * @param response 从controller层通过response获取到的输出流
     * @throws IOException
     */
    public static <T> void exportDataToExcel(List<T> list,
                                             Map<String, String> title,
                                             Map<String, Integer> position,
                                             Map<Integer, List<Integer>> styleMap,
                                             String sheetName,
                                             HttpServletResponse response) throws IOException
    {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet(sheetName);
            Row header = sheet.createRow(0);
            /**设置表头样式*/
            CellStyle headerStyle = workbook.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            // 字体样式
            XSSFFont font = ((XSSFWorkbook) workbook).createFont();
            font.setFontName("Arial");
            font.setFontHeightInPoints((short)14);
            headerStyle.setFont(font);

            /**遍历表头map集合*/
            int col = 0;
            for (String key: title.keySet()) {
                sheet.setColumnWidth(col, 6000);
                // 设置表格头部
                Cell headerCell = header.createCell(position.get(key));
                headerCell.setCellValue(title.get(key) + "");
                headerCell.setCellStyle(headerStyle);
                col++;
            }
            CellStyle style = workbook.createCellStyle();
            CellStyle errorStyle = workbook.createCellStyle();
            style.setWrapText(true);
            //错误位置样式
            errorStyle.setFillForegroundColor(IndexedColors.RED.getIndex());
            errorStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            /*
             * 遍历要导出列表的数据data 并与title的key相比较， 确认后插入值
             * 创建列时，根据title的key然后将值插入到对应的列中（position，dataMap，title三个集合的key值是一一对应的）
             */
//            if (data != null && data.size() > 0)
//            {
//                int r = 0;
//                for (Map<String, Object> dataMap : data) {
//                    Row row = sheet.createRow(r + 1);
//                    for (String dkey : dataMap.keySet()) {
//                        for (String key : title.keySet()) {
//                            if (key.equals(dkey)) {
//                                Cell cell = row.createCell(position.get(key));
//                                cell.setCellValue(dataMap.get(dkey) + "");
//                                if(r%2==0)
//                                {
//                                    cell.setCellStyle(style);
//                                }else
//                                {
//                                    cell.setCellStyle(errorStyle);
//                                }
//                                break;
//                            }
//                        }
//                    }
//                    r++;
//                }
//            }

            if(list!=null&&list.size()>0)
            {
                int r = 1;
                for (T obj : list)
                {
                    if (obj == null)
                    {
                        return;
                    }
                    Row row = sheet.createRow(r);
                    //反射获取值
                    Field[] fields = obj.getClass().getDeclaredFields();
                    for (int j = 0; j < fields.length; j++)
                    {
                        Field field = fields[j];
                        // 暴力破解
                        field.setAccessible(true);
                        try
                        {
                            String name = field.getName();
                            String value = field.get(obj)!=null?field.get(obj).toString():"";
                            Integer index = position.get(name);
                            Cell cell = row.createCell(index);
                            cell.setCellValue(value);
                            List<Integer> columns = styleMap.get(r);
                            //设置样式
                            if(columns!=null&&columns.contains(index))
                            {
                                cell.setCellStyle(errorStyle);
                            }
                        } catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                    r++;
                }
            }
            workbook.write(response.getOutputStream());
        } catch (Exception ex) {
           // log.error("export data", ex);
           // throw new ExcelExportException("导出列表失败。");
        }
    }

    /**
     * 获取列的位置
     * @param name
     * @param treeMap
     * @return
     */
    private static Integer getIndex(String name, TreeMap<String, String> treeMap)
    {
        Integer index = 0;
        for (Map.Entry<String, String> map : treeMap.entrySet())
        {
            String key = map.getKey();
            if(key.equals(name))
            {
                break;
            }
            index++;
        }
        return index;
    }
}
